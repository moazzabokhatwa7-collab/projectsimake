# Web Design System

## Responsive layout

### Breakpoints

| Breakpoint | Width | Target |
|---|---|---|
| Mobile | 320–639px | Phones (portrait) |
| Tablet | 640–1023px | Tablets, small landscape |
| Desktop | 1024–1439px | Laptops |
| Wide | 1440px+ | Desktops, large monitors |

### CSS layout systems

**CSS Grid** — for 2D layouts (page structure, card grids):

```css
.page {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 3fr);
  gap: 24px;
}

.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 16px;
}
```

**Flexbox** — for 1D layouts (rows, toolbars, nav):

```css
.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}
```

### Mobile-first

Write mobile styles first, then enhance with `min-width` media queries:

```css
/* Base: mobile */
.container { padding: 16px; }

/* Tablet+ */
@media (min-width: 640px) {
  .container { padding: 24px; }
}

/* Desktop+ */
@media (min-width: 1024px) {
  .container { padding: 32px; max-width: 1200px; margin: 0 auto; }
}
```

## Typography (web)

### Font stack

Use system font stacks for performance and native feel:

```css
--font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
--font-serif: Georgia, "Times New Roman", serif;
--font-mono: "SF Mono", "Fira Code", "JetBrains Mono", monospace;
```

### Fluid type scale

```css
:root {
  --text-xs: clamp(0.75rem, 0.7rem + 0.25vw, 0.875rem);
  --text-sm: clamp(0.875rem, 0.8rem + 0.35vw, 1rem);
  --text-base: clamp(1rem, 0.95rem + 0.25vw, 1.125rem);
  --text-lg: clamp(1.125rem, 1rem + 0.75vw, 1.5rem);
  --text-xl: clamp(1.5rem, 1.2rem + 1.25vw, 2.25rem);
  --text-2xl: clamp(2rem, 1.2rem + 2.5vw, 3.5rem);
}

body { font-size: var(--text-base); line-height: 1.6; }
h1 { font-size: var(--text-2xl); line-height: 1.1; }
h2 { font-size: var(--text-xl); line-height: 1.2; }
```

### Line height

| Context | Line height |
|---|---|
| Headlines | 1.1–1.2 |
| Body text | 1.5–1.6 |
| UI labels | 1.3 |

## Color (web)

### CSS custom properties with dark mode

```css
:root {
  --color-bg: #ffffff;
  --color-surface: #f5f5f7;
  --color-text: #1d1d1f;
  --color-text-secondary: #6e6e73;
  --color-border: rgba(0, 0, 0, 0.1);
  --color-primary: #0071e3;
  --color-primary-hover: #0058b0;
}

@media (prefers-color-scheme: dark) {
  :root {
    --color-bg: #000000;
    --color-surface: #1c1c1e;
    --color-text: #f5f5f7;
    --color-text-secondary: #98989d;
    --color-border: rgba(255, 255, 255, 0.15);
    --color-primary: #0a84ff;
    --color-primary-hover: #409cff;
  }
}
```

### Manual dark mode toggle

```css
[data-theme="dark"] {
  --color-bg: #000000;
  --color-surface: #1c1c1e;
  /* ... */
}
```

```js
document.documentElement.setAttribute('data-theme', 'dark');
```

## Accessibility (web — WCAG 2.1 AA)

### Contrast

- Body text: **4.5:1** minimum
- Large text (24px+ or 19px+ bold): **3:1** minimum
- UI components and graphics: **3:1** minimum

### Semantic HTML

```html
<header>  <!-- Site header -->
<nav>     <!-- Navigation -->
<main>    <!-- Primary content -->
<article> <!-- Self-contained content -->
<aside>   <!-- Sidebar, related content -->
<footer>  <!-- Site footer -->

<button>  <!-- NOT <div onclick> -->
<a>       <!-- For navigation, NOT <span> -->
<label>   <!-- Associated with <input> via for/id -->
```

### ARIA

- Only add ARIA when semantic HTML is insufficient
- `aria-label` on icon-only buttons
- `role="alert"` on dynamic error messages
- `aria-expanded` on toggles
- `aria-live="polite"` for dynamic content updates
- `role="dialog"` + `aria-modal="true"` on modals

### Focus management

- Visible focus indicator on all interactive elements (never `outline: none` without replacement)
- Logical tab order follows visual order
- Modal focus trap — focus stays inside modal while open, restored on close
- Skip-to-main-content link at top of page

### Keyboard

- All interactive elements operable by keyboard
- Enter/Space activates buttons
- Tab moves forward, Shift+Tab moves backward
- Escape closes modals and dropdowns
- Arrow keys for tab lists, menus, and sliders

### Reduced motion

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

## Performance

### Targets

| Metric | Target |
|---|---|
| LCP (Largest Contentful Paint) | < 2.5s |
| CLS (Cumulative Layout Shift) | < 0.1 |
| INP (Interaction to Next Paint) | < 200ms |
| Lighthouse Performance | ≥ 90 |

### Rules

- Use system font stacks (zero download) or `font-display: swap` for web fonts
- Lazy-load images below the fold (`loading="lazy"`)
- Use `srcset` for responsive images
- Minimize CSS — ship only what's needed
- Use CSS Grid/Flexbox instead of JavaScript layout
- Avoid layout thrashing — batch DOM reads/writes
- Use `will-change` sparingly for animated elements

## Material approximation (web)

Web doesn't have Apple's materials, but `backdrop-filter` approximates translucency:

```css
.navbar {
  background: rgba(255, 255, 255, 0.72);
  backdrop-filter: saturate(180%) blur(20px);
  -webkit-backdrop-filter: saturate(180%) blur(20px);
}

@media (prefers-color-scheme: dark) {
  .navbar {
    background: rgba(0, 0, 0, 0.72);
  }
}
```
