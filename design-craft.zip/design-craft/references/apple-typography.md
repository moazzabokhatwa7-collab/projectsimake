# Apple Typography System

## System font: San Francisco (SF Pro)

San Francisco is the system font on all Apple platforms. It scales automatically, handles Dynamic Type, and ships with the OS. Use it unless there is a strong brand reason to use another font.

### SwiftUI

```swift
Text("Hello").font(.body)       // System font, handles Dynamic Type
Text("Title").font(.title)       // Larger, bold
Text("Large").font(.largeTitle)  // Largest standard style
```

## Apple text styles

These are the standard text styles that handle Dynamic Type automatically:

| SwiftUI style | Size (pt) | Weight | Use |
|---|---|---|---|
| `.largeTitle` | 34 | 700 | Top-level screen titles |
| `.title` | 28 | 700 | Primary section titles |
| `.title2` | 22 | 700 | Secondary section titles |
| `.title3` | 20 | 600 | Card titles, row titles |
| `.headline` | 17 | 600 | Emphasized body, button labels |
| `.body` | 17 | 400 | Body text (default) |
| `.callout` | 16 | 400 | Secondary body text |
| `.subheadline` | 15 | 400 | Subtitles, metadata |
| `.footnote` | 13 | 400 | Footnotes, secondary info |
| `.caption` | 12 | 400 | Captions, labels |
| `.caption2` | 11 | 400 | Smallest captions |

### Using text styles in SwiftUI

```swift
VStack(alignment: .leading) {
  Text("Settings").font(.largeTitle).fontWeight(.bold)
  Text("Manage your account").font(.subheadline).foregroundStyle(.secondary)
  Text("You can change your profile, password, and preferences below.")
    .font(.body)
}
```

## Dynamic Type

Users can scale text from **XS** to **XXXL accessibility size**.

### Rules

- Always use SwiftUI text styles — they scale automatically.
- Never hardcode font sizes (e.g., `.font(.system(size: 17))`) — they break Dynamic Type.
- If you must use a custom font, wrap it with `.scaledFont()` to participate in Dynamic Type.
- Test at both extremes: **xSmall** and **xxxLarge + accessibility**.
- Ensure text does not clip at large sizes — use `minimumScaleFactor` or allow wrapping.
- Use `@ScaledMetric` for spacing and sizing that should scale with text.

### ScaledMetric

```swift
@ScaledMetric private var spacing: CGFloat = 16

VStack(spacing: spacing) {
  // Spacing scales with Dynamic Type
}
```

## Custom fonts

Custom fonts are acceptable if licensed. Rules:

- Support Dynamic Type through `.scaledFont()` or `@ScaledMetric`.
- Do not sacrifice legibility — test at all Dynamic Type sizes.
- Provide the font in the project and reference by PostScript name.

```swift
Text("Brand").font(.custom("BrandFont-Regular", size: 17, relativeTo: .body))
```

## SF Symbols

SF Symbols is Apple's icon library — 6,000+ symbols designed to pair with San Francisco.

### Properties

- Free and optimized for Apple platforms
- Accessible — built-in VoiceOver names
- Scale with Dynamic Type
- Dark-mode aware
- Support weight, scale, and rendering modes

### Rendering modes

| Mode | SwiftUI | Use |
|---|---|---|
| Monochrome | `.symbolRenderingMode(.monochrome)` | Single-color icons |
| Hierarchical | `.symbolRenderingMode(.hierarchical)` | Depth with opacity layers |
| Palette | `.symbolRenderingMode(.palette)` | Multiple specific colors |
| Multicolor | `.symbolRenderingMode(.multicolor)` | Automatic multicolor (e.g., weather) |

### Usage

```swift
Image(systemName: "star.fill")
  .symbolRenderingMode(.hierarchical)
  .foregroundStyle(.yellow)

Label("Favorites", systemImage: "heart.fill")

// Tab bar
TabView {
  HomeView().tabItem { Label("Home", systemImage: "house.fill") }
}
```

### Symbol weights

SF Symbols support weights matching SF Pro: ultralight, thin, light, regular, medium, semibold, bold, heavy, black.

```swift
Image(systemName: "heart")
  .font(.system(size: 24, weight: .semibold))
```

### Browsing symbols

Download the SF Symbols app from Apple Developer to browse all 6,000+ symbols and copy their exact names. Never guess symbol names — verify in the SF Symbols app.
