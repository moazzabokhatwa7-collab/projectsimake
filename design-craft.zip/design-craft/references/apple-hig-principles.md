# Apple HIG — Core Principles, Navigation, Materials, Motion & Accessibility

## Six core HIG principles

1. **Hierarchy** — Visual weight matches importance. The most important action is the most prominent.
2. **Harmony** — Visual style is consistent throughout the app. No fonts changing between screens, no random color shifts.
3. **Consistency** — Patterns learned in one part of the app work the same in every part.
4. **Feedback** — Every user action gets clear feedback: visual, haptic, or auditory.
5. **Depth** — Layered surfaces (sheets, popovers, modals) convey relationships between screens.
6. **Direct manipulation** — Users feel like they're touching their data, not telling the app what to do.

## Navigation patterns

| Pattern | When to use | Platform |
|---|---|---|
| Tab bar | Top-level, parallel app sections (3–5 tabs) | iOS, watchOS (compact) |
| NavigationStack | Hierarchical drill-down, master/detail | All Apple platforms |
| Modal sheet | Self-contained tasks (user must finish or cancel) | All |
| Popover | Transient controls | iPad, Mac (never iPhone — use sheets) |
| Inspector / sidebar | Persistent secondary content | iPad, Mac |
| Page-based | Swipeable flat pages | watchOS |
| NavigationSplitView | Multi-column layouts | iPadOS, macOS, visionOS |

### Navigation rules

- System back-swipe must work everywhere. Custom back buttons that don't behave like the standard are a rejection trigger.
- Use `NavigationStack` (not the deprecated `NavigationView`) in modern SwiftUI.
- Avoid hamburger menus on iOS — use a tab bar or sidebar instead.
- Present self-contained tasks as modal sheets, not pushed screens.

## Materials & depth

Apple materials are translucent surfaces that blur and tint content behind them:

| Material | SwiftUI | Opacity feel | Use |
|---|---|---|---|
| Ultra thin | `.ultraThinMaterial` | Very subtle | Navigation bars over content |
| Thin | `.thinMaterial` | Subtle | Toolbars, search bars |
| Regular | `.regularMaterial` | Medium | Cards over content |
| Thick | `.thickMaterial` | More opaque | Popovers |
| Ultra thick | `.ultraThickMaterial` | Nearly opaque | Modals needing separation |

### Material rules

- Use materials for navigation bars, sheets, popovers — not solid backgrounds.
- Solid backgrounds where Apple uses materials make the app feel "off."
- Materials create the iOS sense of depth — layered surfaces communicate screen relationships.
- On web, approximate with `backdrop-filter: blur()` + semi-transparent background.

## Motion & animation

| Rule | Detail |
|---|---|
| Duration | 250–400ms for standard transitions |
| Easing | Use spring animations (`.spring()`) for natural feel; avoid linear |
| Reduce Motion | Support via `@Environment(\.accessibilityReduceMotion)` |
| Purpose | Animation is communication, not decoration |
| Restraint | Don't make every transition a one-second flourish |
| State changes | Use subtle fade or slide, not pop-in |

### Haptic feedback

Use haptics for important moments — not every tap.

| Haptic | When |
|---|---|
| `.light` | Toggle, selection |
| `.medium` | Button press confirmation |
| `.heavy` | Destructive action confirmation |
| `.success` | Task completed |
| `.warning` | Error or warning |
| `.error` | Operation failed |

SwiftUI: `sensoryFeedback(.success, trigger:)` or `UIImpactFeedbackGenerator`.

## Accessibility (mandatory — not optional)

Skipping accessibility closes the app to ~15% of potential users and violates Apple's stated guidance.

### VoiceOver

- Every interactive element has a meaningful `.accessibilityLabel()`.
- Test VoiceOver on a real device through every flow.
- SF Symbols include built-in VoiceOver names.
- Group related elements with `.accessibilityElement(children: .combine)`.

### Dynamic Type

- Users can scale text from XS to XXXL accessibility size.
- Use SwiftUI text styles (`.font(.body)`, `.font(.headline)`) — they handle Dynamic Type automatically.
- Hardcoded font sizes break at accessibility sizes.
- Test at xSmall and xxxLarge + accessibility.
- Ensure text does not clip at large sizes — use `minimumScaleFactor` or allow wrapping.

### Color accessibility

- Never communicate state through color alone — pair with icon, text label, or position.
- Maintain ≥ 4.5:1 contrast for body text (WCAG AA).
- Especially important on tinted backgrounds.

### Touch targets

- All touch targets ≥ 44 × 44 pt.
- Buttons below 44pt are a common rejection trigger and accessibility violation.

### Motion & transparency

- Support Reduce Motion (`@Environment(\.accessibilityReduceMotion)`).
- Support Reduce Transparency (`@Environment(\.accessibilityReduceTransparency)`).
- Provide non-animated alternatives for critical transitions.

### Voice Control

- Test Voice Control compatibility.
- Elements should be activatable by name.

### Pre-submission accessibility checklist

1. VoiceOver works through every flow.
2. Dynamic Type tested at xSmall and xxxLarge + accessibility.
3. All touch targets ≥ 44 × 44 pt.
4. Color is not the only method communicating state.
5. Contrast ≥ 4.5:1 for body text.
6. Reduce Motion and Reduce Transparency supported.
7. Voice Control compatible.
