# Design Tokens

## Token taxonomy

Tokens are the atomic design decisions. Everything in the UI resolves to a token — never hardcode a hex code, font size, or spacing value in a component.

### 1. Color tokens

Use a three-tier naming: `category-role-variant`.

**Semantic colors** (adapt to light/dark automatically):

| Token | Light | Dark | Use |
|---|---|---|---|
| `color/primary` | Brand color | Brand color (adjusted) | Primary actions, links |
| `color/secondary` | Brand secondary | Brand secondary (adjusted) | Secondary actions |
| `color/background` | #FFFFFF | #000000 / #1C1C1E | App/page background |
| `color/surface` | #F2F2F7 | #1C1C1E | Cards, sheets |
| `color/surface-elevated` | #FFFFFF | #2C2C2E | Modals, popovers |
| `color/text/primary` | #000000 | #FFFFFF | Body text |
| `color/text/secondary` | #3C3C43 60% | #EBEBF5 60% | Captions, labels |
| `color/text/tertiary` | #3C3C43 30% | #EBEBF5 30% | Placeholders |
| `color/border` | #3C3C43 12% | #545458 65% | Dividers, borders |
| `color/success` | #34C759 | #30D158 | Success states |
| `color/warning` | #FF9F0A | #FF9F0A | Warning states |
| `color/error` | #FF3B30 | #FF453A | Error states |

Apple note: map these to SwiftUI semantic colors (`.primary`, `.secondary`, `Color(.systemBackground)`, etc.) where possible. See `apple-color-system.md`.

Web note: expose as CSS custom properties with light/dark media queries:

```css
:root {
  --color-bg: #FFFFFF;
  --color-surface: #F2F2F7;
  --color-text-primary: #000000;
}
@media (prefers-color-scheme: dark) {
  :root {
    --color-bg: #000000;
    --color-surface: #1C1C1E;
    --color-text-primary: #FFFFFF;
  }
}
```

### 2. Typography tokens

| Token | Size | Weight | Line height | Use |
|---|---|---|---|---|
| `text/display` | 48–56px | 700 | 1.1 | Hero headlines |
| `text/title-1` | 34px | 700 | 1.2 | Page titles (Apple: Large Title) |
| `text/title-2` | 28px | 700 | 1.2 | Section titles (Apple: Title 1) |
| `text/title-3` | 22px | 600 | 1.3 | Card titles (Apple: Title 2) |
| `text/headline` | 17px | 600 | 1.3 | Emphasized body (Apple: Headline) |
| `text/body` | 17px | 400 | 1.5 | Body text (Apple: Body) |
| `text/callout` | 16px | 400 | 1.4 | Secondary body |
| `text/subheadline` | 15px | 400 | 1.4 | Subtitles (Apple: Subheadline) |
| `text/footnote` | 13px | 400 | 1.4 | Footnotes |
| `text/caption` | 12px | 400 | 1.4 | Captions, labels |

Apple note: these map to SwiftUI's built-in text styles (`.largeTitle`, `.title`, `.title2`, `.title3`, `.headline`, `.body`, `.callout`, `.subheadline`, `.footnote`, `.caption`, `.caption2`). See `apple-typography.md`.

### 3. Spacing tokens

Use a 4pt base unit:

| Token | Value | Use |
|---|---|---|
| `space/0` | 0 | No gap |
| `space/1` | 4px | Icon gaps, tight |
| `space/2` | 8px | Button padding, small gaps |
| `space/3` | 12px | Card padding |
| `space/4` | 16px | Standard margin, section gaps |
| `space/5` | 20px | Card gaps |
| `space/6` | 24px | Section padding |
| `space/8` | 32px | Page padding |
| `space/10` | 40px | Section separation |
| `space/12` | 48px | Hero spacing |

### 4. Radius tokens

| Token | Value | Use |
|---|---|---|
| `radius/none` | 0 | Full-bleed images |
| `radius/sm` | 8px | Small controls, tags |
| `radius/md` | 12px | Cards, inputs |
| `radius/lg` | 16px | Modals, sheets |
| `radius/full` | 9999px | Avatars, pills |

### 5. Elevation tokens

| Token | Shadow | z-index | Use |
|---|---|---|---|
| `elevation/0` | none | 0 | Flat surfaces |
| `elevation/1` | 0 1px 3px rgba(0,0,0,0.08) | 10 | Sticky headers, cards |
| `elevation/2` | 0 4px 12px rgba(0,0,0,0.12) | 20 | Dropdowns, popovers |
| `elevation/3` | 0 12px 32px rgba(0,0,0,0.16) | 30 | Modals, sheets |

Apple note: use materials (`.ultraThinMaterial`, `.thinMaterial`, etc.) instead of shadows on Apple platforms. See `apple-color-system.md`.

### 6. Motion tokens

| Token | Duration | Easing | Use |
|---|---|---|---|
| `motion/fast` | 150ms | ease-out | Micro-interactions, toggles |
| `motion/normal` | 250ms | ease-in-out | State transitions, expand/collapse |
| `motion/slow` | 400ms | cubic-bezier(0.4, 0, 0.2, 1) | Page transitions, modals |
| `motion/spring` | spring(response: 0.5, dampingFraction: 0.8) | — | iOS-native feel (SwiftUI) |

Apple note: typical iOS animation duration is 250–400ms. Use spring animations (`.spring()`) for natural feel. Always respect Reduce Motion. See `apple-hig-principles.md`.

## Token naming rules

- Use `category/role` or `category/role-variant` format
- Never use raw values in component code — always reference tokens
- Dark mode variants are defined at the token level, not the component level
- Document every token with its intended use

## Implementation formats

### CSS custom properties (web)

```css
:root {
  --color-primary: #007AFF;
  --color-bg: #FFFFFF;
  --space-4: 16px;
  --radius-md: 12px;
  --motion-normal: 250ms ease-in-out;
}
```

### Tailwind config (web)

```js
module.exports = {
  theme: {
    colors: { primary: '#007AFF', bg: '#FFFFFF', surface: '#F2F2F7' },
    spacing: { 1: '4px', 2: '8px', 3: '12px', 4: '16px' },
    borderRadius: { sm: '8px', md: '12px', lg: '16px' },
  },
};
```

### SwiftUI environment (Apple)

```swift
// Define as environment values or a design system struct
struct DesignTokens {
    static let primary = Color.blue
    static let spacing4: CGFloat = 16
    static let radiusMd: CGFloat = 12
}
```
