# Component Patterns

Every component must define: anatomy, states, sizing, accessibility, and dark mode. Design components as a system — never one-offs.

## Buttons

### Anatomy
Container + label (optional icon)

### States
default → hover → active (pressed) → focused → disabled → loading

### Sizing

| Size | Height | Padding | Font | Touch target |
|---|---|---|---|---|
| Small | 32px | 8px 12px | 13px | 44×44pt min (Apple) |
| Medium | 40px | 12px 16px | 15px | 44×44pt min |
| Large | 48px | 16px 24px | 17px | 44×44pt min |

### Variants
- **Primary** — filled background, white text (the main action on screen)
- **Secondary** — tinted background or outlined
- **Ghost** — no background, text only
- **Destructive** — red background/border (delete, remove)

### Accessibility
- `.accessibilityLabel()` on icon-only buttons
- Minimum 44×44pt touch target (Apple)
- Disabled state uses 40% opacity, not gray color
- Loading state keeps the button in place (no layout shift)

### SwiftUI
```swift
Button("Save") { save() }
  .buttonStyle(.borderedProminent)
  .controlSize(.large)
```

### HTML/CSS
```html
<button class="btn btn-primary btn-md">Save</button>
```

## Text inputs

### Anatomy
Label + container + input text + helper/error text (optional icon)

### States
default → focused → filled → error → disabled

### Rules
- Label is always visible (not placeholder-only)
- Error message appears below the field, not as a toast
- Error state: red border + red helper text + error icon
- Min height 44pt (Apple) / 40px (web)
- Autofocus on first field in forms

### Accessibility
- `<label>` associated with `<input>` (web)
- `.accessibilityLabel()` for decorative inputs (Apple)
- Error text has `role="alert"` (web) or `.accessibilityHint()` (Apple)

## Cards

### Anatomy
Container + content (header, body, footer optional)

### Rules
- Use `radius/md` (12px) or `radius/lg` (16px)
- Padding from spacing scale, never arbitrary
- Surface color from token, not white hardcoded
- No shadow on Apple — use surface color differentiation or materials
- Web: `elevation/1` shadow for cards

## Lists

### Anatomy
Row + leading content (icon/avatar) + title + subtitle + trailing accessory (chevron, action)

### Rules
- Row height minimum 44pt (Apple) / 48px (web)
- Swipe actions on iOS (`.swipeActions`)
- Leading + trailing accessories aligned to edges
- Section headers use `text/subheadline` weight 600
- Dividers use `color/border` token, full-bleed or inset

### SwiftUI
```swift
List {
  Section("Settings") {
    NavigationLink("Account") { AccountView() }
    NavigationLink("Notifications") { NotificationsView() }
  }
}
.listStyle(.insetGrouped)
```

## Navigation bars (Apple)

### Rules
- Large title for top-level screens (collapses on scroll)
- Leading: back button (system-provided) or close button
- Trailing: primary action or contextual menu
- Use `.toolbar()` in SwiftUI
- Translucent material background (not solid)

### SwiftUI
```swift
.navigationTitle("Settings")
.navigationBarTitleDisplayMode(.large)
.toolbar {
  ToolbarItem(placement: .topBarTrailing) {
    Button("Edit") { /* ... */ }
  }
}
```

## Tab bars (Apple)

### Rules
- 3–5 tabs maximum
- SF Symbols for tab icons (never custom icons unless brand requires)
- Label below icon
- Active tab uses tint color
- Use `.tabViewStyle` on iPad for sidebar tab bar

### SwiftUI
```swift
TabView {
  HomeView().tabItem { Label("Home", systemImage: "house") }
  SearchView().tabItem { Label("Search", systemImage: "magnifyingglass") }
  ProfileView().tabItem { Label("Profile", systemImage: "person") }
}
```

## Modals / sheets

### Anatomy
Overlay + container + content + dismiss control

### Rules
- Full-screen for complex tasks; sheet for quick actions
- Dismiss by swipe-down (iOS) or click-outside (web)
- No nested modals — use navigation or sequential sheets
- Web: trap focus inside modal, restore on close
- Apple: use `.sheet`, `.fullScreenCover`, or `.popover`

### SwiftUI
```swift
.sheet(isPresented: $showSheet) {
  SettingsView()
    .presentationDetents([.medium, .large])
}
```

## Avatars

### Rules
- Circular (`radius/full`)
- Sizes: 24px (inline), 32px (list), 48px (profile), 96px (detail)
- Fallback: initials on `color/primary` background
- Image with `aspectRatio(contentMode: .fill)` clipped to circle

## Badges

### Rules
- Pill shape (`radius/full`)
- Small (16–20px height)
- Count badges: red background, white text, min 20×20pt
- Status badges: semantic colors (success/warning/error)
- Never use color alone — include text or icon

## Alerts

### Rules
- Title + message + actions
- Destructive action styled red
- Two buttons max (cancel + confirm); three is the absolute limit
- Apple: use `.alert` modifier
- Web: use `role="alertdialog"` and `aria-modal="true"`
