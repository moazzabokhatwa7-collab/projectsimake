# Apple Color System

## Semantic colors (use these by default)

Semantic colors adapt automatically to light and dark mode. Always prefer semantic over raw colors.

| SwiftUI | Light mode | Dark mode | Use |
|---|---|---|---|
| `.primary` | Black | White | Primary text |
| `.secondary` | 60% black | 60% white | Secondary text |
| `Color(.systemBackground)` | #FFFFFF | #000000 | App background |
| `Color(.secondarySystemBackground)` | #F2F2F7 | #1C1C1E | Card/sheet background |
| `Color(.tertiarySystemBackground)` | #FFFFFF / #F2F2F7 | #2C2C2E | Grouped backgrounds |
| `Color(.separator)` | 12% black | 65% white | Dividers |
| `Color(.systemFill)` | 12% black | 36% white | Filled controls |
| `Color(.secondarySystemFill)` | 10% black | 32% white | Secondary fills |
| `Color(.tertiarySystemFill)` | 8% black | 24% white | Tertiary fills |
| `Color(.quaternarySystemFill)` | 6% black | 18% white | Quaternary fills |

### Using semantic colors

```swift
Text("Hello").foregroundStyle(.primary)           // Adapts to dark mode
Text("Subtitle").foregroundStyle(.secondary)       // Lighter, adapts
Rectangle().fill(Color(.systemBackground))          // Background
```

## System tint colors

| Color | SwiftUI | Use |
|---|---|---|
| Blue | `.blue` / `.tint(.blue)` | Default interactive |
| Green | `.green` | Success |
| Orange | `.orange` | Warning |
| Red | `.red` | Destructive, error |
| Purple | `.purple` | Accent |
| Pink | `.pink` | Accent |
| Yellow | `.yellow` | Attention |
| Indigo | `.indigo` | Accent |
| Teal | `.teal` | Accent |
| Mint | `.mint` | Accent |

### Accent color

Set the app's accent color in the asset catalog (AccentColor). It propagates to all standard controls automatically.

```swift
// In Assets.xcassets → AccentColor
// Or programmatically:
.tint(.purple)
```

## Brand colors in light and dark mode

Use asset catalog colors with light and dark variants for brand colors:

1. Open Assets.xcassets
2. Right-click → New Color Set
3. Set "Appearances" to "Any, Dark"
4. Define light and dark hex values separately

```swift
// Reference in code
Text("Brand").foregroundStyle(Color("BrandBlue"))
```

## Dark mode rules

Dark mode is not optional — every screen must be tested in both light and dark.

1. Every screen tested in dark mode
2. No screens stuck in light mode while others are dark
3. Use semantic colors — they adapt automatically
4. Brand colors need dark-mode-adjusted variants (slightly brighter for readability)
5. Test contrast on tinted backgrounds — especially important in dark mode
6. Images may need dark-mode variants (use asset catalog appearances)

### SwiftUI dark mode detection

```swift
@Environment(\.colorScheme) var colorScheme

if colorScheme == .dark {
  // Dark mode specific adjustments
}
```

## Contrast requirements

- Minimum: **WCAG AA — 4.5:1** for body text
- Large text: **3:1**
- Test every color pair in both light and dark mode
- Especially important on tinted backgrounds (tinted buttons, colored cards)

## Materials (translucency)

Materials replace solid backgrounds for layered surfaces. See `apple-hig-principles.md` for full material guidance.

```swift
// Navigation bar with material
.navigationBarBackground(.ultraThinMaterial)

// Card with material background
.background(.regularMaterial)

// Sheet with material
.background(.thickMaterial)
```

## Color communication rules

Never use color alone to communicate state. Pair color with:

- An icon (e.g., red trash + "Delete" label)
- A text label (e.g., "Active" in green + checkmark)
- Position (e.g., error at bottom of field)

This is critical for color-blind users (~8% of the population).
