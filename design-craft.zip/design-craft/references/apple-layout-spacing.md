# Apple Layout & Spacing Rules

## Safe areas

Respect system safe areas — they define where content must not overlap system UI.

### What to respect

| Element | Platform | Detail |
|---|---|---|
| Dynamic Island | iPhone 14 Pro+ | Top center — don't overlay |
| Notch | iPhone X–13 Pro | Top center — don't overlay |
| Home indicator | All notch iPhones | Bottom — leave room for swipe |
| Status bar | All iPhones | Top — use `.statusBarHidden` only when justified |
| Rounded screen corners | All modern iPhones | Content shouldn't clip into corners |

### SwiftUI safe area handling

```swift
// Default — respects safe areas
ContentView()

// Extend into safe area (e.g., edge-to-edge background)
ContentView()
  .background(Color(.systemBackground).ignoresSafeArea())

// Add inset content above safe area (e.g., bottom bar)
ContentView()
  .safeAreaInset(edge: .bottom) {
    BottomBar()
  }

// Full-screen background with safe-area content
ZStack {
  Color(.systemBackground).ignoresSafeArea()
  VStack { /* content respects safe area */ }
}
```

### Rules

- Content (text, buttons) respects safe areas by default.
- Backgrounds can extend edge-to-edge with `.ignoresSafeArea()`.
- Custom bottom bars use `.safeAreaInset(edge: .bottom)`.
- Never block the home indicator area with interactive elements.
- Test on iPhone SE (smallest screen) and Pro Max (largest).

## Touch targets

**Minimum: 44 × 44 pt** — this is Apple's hard requirement.

- Buttons below 44pt are a common rejection trigger.
- Small icons must have an invisible hit area of at least 44×44pt.
- SwiftUI's standard controls enforce this automatically.
- Custom buttons need explicit frame:

```swift
Button(action: {}) {
  Image(systemName: "plus")
}
.frame(width: 44, height: 44)  // Ensures minimum touch target
```

## Margins

### Standard margins

| Context | Value |
|---|---|
| Standard screen margin | 16pt (leading/trailing) |
| Grouped content inset | 20pt (from screen edge) |
| Section spacing | 24–32pt between sections |
| Card padding | 16pt |
| List row padding | 16pt leading/trailing, 12pt vertical |

### SwiftUI layout

```swift
VStack {
  Text("Title").font(.title2)
  Text("Body text").font(.body)
}
.padding(.horizontal, 16)  // Standard margin
.padding(.vertical, 12)
```

## Spacing scale

Use a consistent 4pt-based spacing scale:

| Token | Value | Use |
|---|---|---|
| xs | 4pt | Icon gaps, tight spacing |
| sm | 8pt | Button internal padding |
| md | 12pt | Row vertical padding |
| lg | 16pt | Standard margin, card padding |
| xl | 20pt | Card gaps |
| 2xl | 24pt | Section spacing |
| 3xl | 32pt | Page padding |

## Edge-to-edge content

Modern iOS apps push content to screen edges:

- Backgrounds extend edge-to-edge (`.ignoresSafeArea()`)
- Content respects safe areas with standard margins
- Navigation bars use translucent materials over content
- Avoid heavy chrome — let content breathe
- Scrollable content goes under translucent navigation bars

## Grid system

### iOS grid

- No fixed column grid — use adaptive layouts
- `VStack` / `HStack` with `Spacer()` for flexible layouts
- `Grid` (iOS 16+) for aligned grid content
- `LazyVGrid` with `GridItem(.adaptive(minimum:))` for responsive grids

```swift
LazyVGrid(columns: [GridItem(.adaptive(minimum: 160))], spacing: 16) {
  ForEach(items) { item in
    CardView(item: item)
  }
}
```

### iPadOS grid

- Use `NavigationSplitView` for sidebar + detail
- Adaptive column counts based on size class
- Support keyboard shortcuts and trackpad

## Layout testing

| Test | Device | What to check |
|---|---|---|
| iPhone SE test | iPhone SE (smallest) | Everything fits, no clipping, touch targets ≥ 44pt |
| Pro Max test | iPhone Pro Max (largest) | Content doesn't stretch awkwardly, use space meaningfully |
| iPad test | iPad (if supported) | Adaptive layout, sidebar, keyboard shortcuts |
| Dynamic Type | xSmall + xxxLarge | Text doesn't clip, layout doesn't break |
| Dark mode | All devices | Every screen works in dark mode |
