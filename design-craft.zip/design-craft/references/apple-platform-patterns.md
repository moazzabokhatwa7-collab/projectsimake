# Apple Platform-Specific Patterns

## iOS (iPhone)

| Pattern | Detail |
|---|---|
| Navigation | Tab bar (top-level) + NavigationStack (drill-down) |
| Sheets | Full-screen, page sheet, or form sheet for self-contained tasks |
| Popovers | Do not use — use sheets instead |
| Back navigation | System back-swipe must work; never custom back buttons that break swipe |
| Large titles | Use for top-level screens; collapse on scroll |
| Tab bar | 3–5 tabs, SF Symbols icons |
| Haptics | Use for important moments — not every tap |
| Materials | Translucent navigation bars and toolbars |

### iPhone-specific

- Respect Dynamic Island, notch, and home indicator
- Pass the "iPhone SE test" — works on smallest current iPhone
- Edge-to-edge backgrounds, safe-area-respecting content

## iPadOS (iPad)

| Pattern | Detail |
|---|---|
| Navigation | NavigationSplitView (sidebar + detail) or adaptive tab bar |
| Popovers | Use for transient controls (allowed and expected) |
| Inspector | For persistent secondary content |
| Keyboard | Support keyboard shortcuts (⌘N, ⌘W, etc.) |
| Trackpad | Support hover states and pointer interaction |
| Multitasking | Support Split View and Slide Over |
| Layout | Adaptive — use size classes, not device detection |

### SwiftUI

```swift
NavigationSplitView {
  Sidebar()           // Shown on iPad/Mac, collapses on iPhone
} content: {
  MiddleView()        // Optional middle column
} detail: {
  DetailView()
}
```

## macOS

| Pattern | Detail |
|---|---|
| Window | Window-based with toolbar |
| Navigation | Sidebar + content (NavigationSplitView or NSSplitView) |
| Popovers | Use for transient controls |
| Inspector | For persistent secondary content |
| Menus | Full menu bar support |
| Keyboard | Extensive keyboard shortcuts expected |
| Touch Bar | Optional (deprecated on newer Macs) |

### Mac-specific rules

- Use `NavigationSplitView` — it adapts to Mac window layout
- Support window resizing at all sizes
- Provide menu bar items for key actions
- Use standard Mac toolbar patterns (leading/trailing items)
- Support drag and drop where natural

## watchOS

| Pattern | Detail |
|---|---|
| Navigation | Page-based (swipe) or NavigationStack |
| Layout | Full-screen, minimal chrome |
| Touch targets | 44×44pt minimum (harder on small screen) |
| Text | Minimal — use short labels, not paragraphs |
| Color | Use system colors for readability |
| Haptics | Wrist-based haptic feedback is primary |
| Complications | Support complications for watch face |
| Interactive | Support Digital Crown, tap, and swipe |

### Watch-specific rules

- Design for glanceability — 2 seconds of attention
- No tab bars — use page-based or hierarchical navigation
- Use `WKInterface` controls or SwiftUI watchOS views
- Keep interactions minimal — 1–2 taps to complete a task
- Use haptics for feedback (taps on the wrist are felt more than seen)

## visionOS

| Pattern | Detail |
|---|---|
| Navigation | Tab bar or NavigationSplitView |
| Layout | Depth-aware — content exists in 3D space |
| Materials | Glass materials (translucent surfaces) are signature |
| Windows | Apps run in windows that float in the user's space |
| Ornaments | Bottom-aligned controls (replacing tab bars in some contexts) |
| Focus | Eyes + pinch for selection; support focus effects |
| Depth | Use subtle depth to convey hierarchy, not just flat layers |

### Vision-specific rules

- Use `.glassEffect()` and materials — solid surfaces feel heavy in spatial context
- Support focus states — every interactive element needs a clear focus appearance
- Use `OrnamentView` for bottom controls
- Design for comfortable viewing distance (~1.5m)
- Avoid too much text — spatial interfaces favor visual content
- Use depth intentionally — layered content guides attention

## tvOS

| Pattern | Detail |
|---|---|
| Navigation | Tab bar (top) + focus-based navigation |
| Input | Remote control (swipe + select) — no touch |
| Focus | Focus engine manages which element is selected |
| Layout | Large text, comfortable from 10 feet away |
| Color | Use system colors for readability on TV |
| Parallax | Focused items have subtle parallax/zoom |

### TV-specific rules

- Design for 10-foot viewing distance — large text, large touch-equivalent targets
- Use the focus engine — never custom focus management
- Focused elements should have clear visual change (scale, glow, parallax)
- Use `Button` and standard focusable controls
- Minimize text input — use pickers and suggestions
- Support Siri Remote: swipe, select, menu, play/pause
