# Design System Spec Template

> Document the complete design system. Use during Phase 2 (Design Tokens) and as ongoing reference.

---

## Design System: [Name]

### Overview

**Platforms:** [iOS / Web / macOS / ...]
**Brand personality:** [3–5 adjectives]
**Design philosophy:** [1–2 sentences]

---

## Color tokens

### Semantic colors

| Token | Light | Dark | Use |
|---|---|---|---|
| `color/primary` | | | |
| `color/secondary` | | | |
| `color/background` | | | |
| `color/surface` | | | |
| `color/text/primary` | | | |
| `color/text/secondary` | | | |
| `color/border` | | | |
| `color/success` | | | |
| `color/warning` | | | |
| `color/error` | | | |

### Contrast verification

| Pair | Ratio | WCAG AA? |
|---|---|---|
| Primary text on background | | |
| Secondary text on surface | | |
| Primary button text on primary | | |

---

## Typography tokens

| Token | Size | Weight | Line height | Use |
|---|---|---|---|---|
| `text/display` | | | | |
| `text/title-1` | | | | |
| `text/title-2` | | | | |
| `text/headline` | | | | |
| `text/body` | | | | |
| `text/subheadline` | | | | |
| `text/caption` | | | | |

**Font family:** [system / custom name]
**Dynamic Type / responsive type:** [how it scales]

---

## Spacing tokens

| Token | Value | Use |
|---|---|---|
| `space/1` | | |
| `space/2` | | |
| `space/3` | | |
| `space/4` | | |
| `space/6` | | |
| `space/8` | | |

**Base unit:** [4pt / 8pt]

---

## Radius tokens

| Token | Value | Use |
|---|---|---|
| `radius/none` | | |
| `radius/sm` | | |
| `radius/md` | | |
| `radius/lg` | | |
| `radius/full` | | |

---

## Elevation tokens

| Token | Shadow / z-index | Use |
|---|---|---|
| `elevation/0` | | |
| `elevation/1` | | |
| `elevation/2` | | |
| `elevation/3` | | |

---

## Motion tokens

| Token | Duration | Easing | Use |
|---|---|---|---|
| `motion/fast` | | | |
| `motion/normal` | | | |
| `motion/slow` | | | |

**Reduce motion:** [how it's handled]

---

## Component inventory

| Component | Variants | States | Spec doc |
|---|---|---|---|
| Button | primary, secondary, ghost, destructive | default, hover, active, disabled, loading | [link] |
| Input | text, textarea, select | default, focused, error, disabled | [link] |
| Card | | | |
| List | | | |
| Modal | sheet, full-screen | | |
| Badge | count, status | | |

---

## Platform notes

### Apple (SwiftUI)

- Accent color: [hex / asset catalog]
- Materials: [which materials for which surfaces]
- Navigation pattern: [tab bar / NavigationStack / NavigationSplitView]
- Dark mode: [asset catalog appearances / semantic colors]

### Web

- CSS variables: [file path]
- Dark mode: [prefers-color-scheme / data-theme toggle]
- Responsive breakpoints: [list]
- Font stack: [system / custom]
