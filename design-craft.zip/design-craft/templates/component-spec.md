# Component Spec Template

> Document a single component. Use during Phase 3 (Component Patterns).

---

## Component: [Name]

### Description

[1–2 sentences: what it does, when to use it]

### When NOT to use

[When this component is the wrong choice]

---

## Anatomy

| Element | Description |
|---|---|
| Container | [what wraps the component] |
| Label | [text content] |
| Icon | [leading/trailing icon] |
| Accessory | [trailing element] |

---

## Variants

| Variant | Description | Use case |
|---|---|---|
| | | |

---

## States

| State | Visual change | Trigger |
|---|---|---|
| Default | | Initial render |
| Hover | | Mouse over (web / iPad trackpad) |
| Active/Pressed | | Touch down / mouse down |
| Focused | | Keyboard / focus engine |
| Disabled | | `disabled` attribute / `.disabled()` |
| Loading | | Async action in progress |
| Error | | Validation failure |

---

## Sizing

| Size | Height | Padding | Font size | Touch target |
|---|---|---|---|---|
| Small | | | | 44×44pt (Apple) |
| Medium | | | | 44×44pt (Apple) |
| Large | | | | 44×44pt (Apple) |

---

## Accessibility

| Requirement | Implementation |
|---|---|
| Label | [`.accessibilityLabel()` / `aria-label`] |
| Role | [`.accessibilityAddTraits()` / `role="button"`] |
| Touch target | [≥ 44×44pt] |
| Contrast | [ratio, verified] |
| Keyboard | [Enter/Space activates] |
| VoiceOver | [test flow] |

---

## Color

| Element | Light mode | Dark mode |
|---|---|---|
| Background | | |
| Text | | |
| Border | | |
| Icon | | |

---

## Code

### SwiftUI

```swift
// Component implementation
```

### HTML/CSS

```html
<!-- Component markup -->
```

```css
/* Component styles */
```

---

## Usage examples

```
[Example 1: typical use]
[Example 2: variant use]
```
