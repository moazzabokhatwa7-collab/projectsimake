# Design Craft — Claude Skill

A Claude Agent Skill for designing and engineering professional apps, websites, and design systems with full Apple Human Interface Guidelines compliance.

## What it does

Turns Claude into a senior product designer and front-end engineer that:

- **Designs apps** — iOS, iPadOS, macOS, watchOS, visionOS, tvOS with full HIG compliance
- **Designs websites** — responsive, accessible, performant web interfaces
- **Builds design systems** — tokens, components, patterns, documentation
- **Applies Apple HIG** — six core principles, materials, Dynamic Type, SF Symbols, semantic colors, accessibility
- **Reviews UI** — accessibility, dark mode, platform compliance, professional finish

## Features

### Apple HIG integration
- Six core principles (Hierarchy, Harmony, Consistency, Feedback, Depth, Direct manipulation)
- Navigation patterns per platform (tab bars, NavigationStack, NavigationSplitView, popovers, sheets)
- Materials system (ultraThin through ultraThick)
- SF Pro / Dynamic Type / SF Symbols with all rendering modes
- Semantic colors that adapt to light/dark automatically
- Safe areas, 44pt touch targets, layout rules
- Motion, haptics, Reduce Motion / Reduce Transparency
- Full accessibility: VoiceOver, Dynamic Type, Voice Control, color contrast

### Web design system
- Responsive breakpoints (320px → 1440px+)
- CSS Grid / Flexbox patterns
- Fluid typography with `clamp()`
- Dark mode with `prefers-color-scheme` and manual toggle
- WCAG 2.1 AA accessibility (contrast, semantic HTML, ARIA, focus, keyboard)
- `prefers-reduced-motion` support
- Performance targets (LCP, CLS, INP)
- Material approximation with `backdrop-filter`

### Design tokens
- Color (semantic, light/dark variants)
- Typography (6–8 step scale)
- Spacing (4pt base, 6–8 steps)
- Radius (3–4 steps)
- Elevation (3–4 levels)
- Motion (duration + easing)
- CSS custom properties, Tailwind config, and SwiftUI environment formats

### Component patterns
- Buttons, inputs, cards, lists, navigation bars, tab bars, modals, avatars, badges, alerts
- Every component defines: anatomy, states, sizing, accessibility, dark mode
- SwiftUI and HTML/CSS code for each

## Installation

### Claude Code

```bash
git clone https://github.com/your-username/design-craft.git
cp -r design-craft/design-craft ~/.claude/skills/
```

Or place in your project:

```
your-project/
└── .claude/
    └── skills/
        └── design-craft/
            ├── SKILL.md
            ├── references/
            └── templates/
```

### Claude.ai Projects

1. Open your Project → Settings → Custom instructions
2. Paste the contents of `SKILL.md` (including frontmatter)

## Usage

```
Design a settings screen for my iOS app
```

```
Create a design system with color, type, and spacing tokens for a fintech app
```

```
Build a responsive landing page with dark mode support
```

```
Design a button component with all states and dark mode
```

```
Review my app for Apple HIG compliance and accessibility
```

## File structure

```
design-craft/
├── SKILL.md                              # Hub: workflow, checklists, navigation
├── references/
│   ├── design-tokens.md                  # Color, type, spacing, radius, elevation, motion tokens
│   ├── component-patterns.md             # Buttons, inputs, cards, lists, nav, modals
│   ├── apple-hig-principles.md           # 6 principles, navigation, materials, motion, haptics, accessibility
│   ├── apple-typography.md               # SF Pro, Dynamic Type, text styles, SF Symbols
│   ├── apple-color-system.md             # Semantic colors, dark mode, materials, contrast
│   ├── apple-layout-spacing.md           # Safe areas, 44pt targets, margins, grid
│   ├── apple-platform-patterns.md        # iOS/iPadOS/macOS/watchOS/visionOS/tvOS specifics
│   └── web-design-system.md              # Responsive layout, CSS, accessibility, performance, dark mode
├── templates/
│   ├── design-system-spec.md             # Full design system documentation template
│   └── component-spec.md                 # Single component specification template
├── README.md
└── LICENSE
```

## Compatibility

- **Claude Code** — drop into `.claude/skills/`
- **Claude.ai Projects** — paste SKILL.md into custom instructions
- **Claude API Agent Skills** — load as a skill bundle
- Follows the [Agent Skills specification](https://github.com/anthropics/skills)
- Frontmatter uses only required `name` + `description` fields

## License

MIT — see [LICENSE](LICENSE).
